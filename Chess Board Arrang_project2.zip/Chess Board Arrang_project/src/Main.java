/**
 * Main entry point for the N-Queens Problem Solver.
 *
 * Demonstrates the solver for N = 8, 10, and 12.
 * For each board size:
 *   - Displays the first few solutions visually
 *   - Reports total distinct solutions, nodes explored, and runtime
 *
 * Real-world connections:
 *   - Constraint satisfaction problems (CSP)
 *   - Antenna placement without signal interference
 *   - Task scheduling without resource conflicts
 *
 * @author  DAA Group Project - Q5
 * @version 1.0
 */
public class Main {

    public static void main(String[] args) {

        printHeader();

        // Configuration: { boardSize, maxSolutionsToDisplay }
        // maxDisplay = 0 means print ALL solutions (use carefully for large N)
        int[][] configs = {
            { 8,  3 },   // N=8:  92 solutions, show first 3
            { 10, 2 },   // N=10: 724 solutions, show first 2
            { 12, 1 },   // N=12: 14200 solutions, show first 1
        };

        for (int[] config : configs) {
            int n          = config[0];
            int maxDisplay = config[1];

            NQueens solver = new NQueens(n);
            solver.run(maxDisplay);
        }

        printComplexityAnalysis();
        printRealWorldConnections();
    }

    // -----------------------------------------------------------------------
    // Java 8 compatible repeat helper
    // -----------------------------------------------------------------------

    private static String repeat(String s, int times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) sb.append(s);
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // Display helpers
    // -----------------------------------------------------------------------

    private static void printHeader() {
        System.out.println();
        System.out.println(repeat("*", 55));
        System.out.println("*   DAA Group Project - Q5                           *");
        System.out.println("*   N-Queens Problem: Chess Board Arrangement        *");
        System.out.println("*   Algorithm: Backtracking with Pruning             *");
        System.out.println(repeat("*", 55));
        System.out.println();
        System.out.println("  Representation : 1D array  (queens[row] = column)");
        System.out.println("  Bounding Fn    : Column + diagonal conflict check");
        System.out.println("  Complexity     : O(N!) worst case; pruning reduces");
        System.out.println("                   actual nodes explored drastically.");
    }

    private static void printComplexityAnalysis() {
        System.out.println();
        System.out.println(repeat("*", 55));
        System.out.println("*   Complexity Analysis                              *");
        System.out.println(repeat("*", 55));
        System.out.println();
        System.out.println("  Worst-case time complexity : O(N!)");
        System.out.println("  Space complexity           : O(N)  [recursion depth]");
        System.out.println();
        System.out.println("  Without pruning, we'd explore N^N placements.");
        System.out.println("  The bounding function eliminates branches early:");
        System.out.println("    - Column check   : O(N) per placement");
        System.out.println("    - Diagonal check : O(N) per placement");
        System.out.println("  Combined, pruning cuts the search space by orders");
        System.out.println("  of magnitude compared to brute force.");
        System.out.println();
        System.out.println("  Known solution counts:");
        System.out.printf("    N=8  -> %6d solutions%n",   92);
        System.out.printf("    N=10 -> %6d solutions%n",  724);
        System.out.printf("    N=12 -> %6d solutions%n", 14200);
    }

    private static void printRealWorldConnections() {
        System.out.println();
        System.out.println(repeat("*", 55));
        System.out.println("*   Real-World Connections                           *");
        System.out.println(repeat("*", 55));
        System.out.println();
        System.out.println("  1. Constraint Satisfaction Problems (CSP)");
        System.out.println("     Variables = queens, Domains = columns,");
        System.out.println("     Constraints = no attacks.");
        System.out.println();
        System.out.println("  2. Antenna / Frequency Placement");
        System.out.println("     Place transmitters so signals don't interfere");
        System.out.println("     along rows, columns, or diagonal paths.");
        System.out.println();
        System.out.println("  3. Task Scheduling");
        System.out.println("     Assign tasks to time slots / processors with");
        System.out.println("     no resource conflicts (shared dependencies).");
        System.out.println();
        System.out.println("  4. VLSI Circuit Design");
        System.out.println("     Place components on a chip grid avoiding");
        System.out.println("     electrical interference along shared lines.");
        System.out.println(repeat("*", 55));
        System.out.println();
    }
}
