/**
 * N-Queens Problem Solver using Backtracking with Pruning
 *
 * Problem: Place N queens on an N×N chessboard such that no two queens
 * attack each other (no shared row, column, or diagonal).
 *
 * Approach:
 *  - 1D array representation: queens[row] = column
 *  - Backtracking with bounding function (pruning)
 *  - Supports N = 8, 10, 12 and beyond
 *
 * Complexity: O(N!) worst case; pruning reduces actual runtime significantly.
 *
 * Real-world analogy: Antenna placement, task scheduling, resource allocation.
 *
 * @author  DAA Group Project - Q5
 * @version 1.0
 */
public class NQueens {

    private final int n;           // Board size
    private final int[] queens;    // queens[row] = column position
    private int solutionCount;     // Total distinct solutions found
    private long nodesExplored;    // Nodes visited (for complexity analysis)

    /**
     * Constructs an NQueens solver for an N×N board.
     *
     * @param n the board dimension (number of queens)
     */
    public NQueens(int n) {
        if (n < 1) throw new IllegalArgumentException("Board size must be >= 1");
        this.n = n;
        this.queens = new int[n];
        this.solutionCount = 0;
        this.nodesExplored = 0;
    }

    /**
     * Bounding function: checks whether placing a queen at (row, col)
     * conflicts with any previously placed queen.
     *
     * Checks:
     *  - Same column
     *  - Same major diagonal (row - col == constant)
     *  - Same minor diagonal (row + col == constant)
     *
     * @param row current row being placed
     * @param col candidate column
     * @return true if placement is safe (no conflict), false otherwise
     */
    private boolean isSafe(int row, int col) {
        for (int prevRow = 0; prevRow < row; prevRow++) {
            int prevCol = queens[prevRow];

            // Column conflict
            if (prevCol == col) return false;

            // Diagonal conflict: |row - prevRow| == |col - prevCol|
            if (Math.abs(prevRow - row) == Math.abs(prevCol - col)) return false;
        }
        return true;
    }

    /**
     * Recursive backtracking solver.
     * Places queens row by row, pruning branches that violate constraints.
     *
     * @param row the current row to place a queen in
     * @param maxDisplay maximum number of solutions to print (0 = print all)
     */
    private void solve(int row, int maxDisplay) {
        if (row == n) {
            solutionCount++;
            if (maxDisplay == 0 || solutionCount <= maxDisplay) {
                printSolution(solutionCount);
            }
            return;
        }

        for (int col = 0; col < n; col++) {
            nodesExplored++;
            if (isSafe(row, col)) {
                queens[row] = col;       // Place queen
                solve(row + 1, maxDisplay);
                queens[row] = -1;        // Remove queen (backtrack)
            }
        }
    }

    /**
     * Prints the board for the current solution.
     *
     * @param solutionNumber the index of this solution
     */
    private void printSolution(int solutionNumber) {
        System.out.println("\n  Solution #" + solutionNumber + ":");
        System.out.print("  Column positions (by row): [ ");
        for (int i = 0; i < n; i++) {
            System.out.print((queens[i] + 1)); // 1-indexed for readability
            if (i < n - 1) System.out.print(", ");
        }
        System.out.println(" ]");

        // Visual board
        System.out.println("  Board:");
        for (int row = 0; row < n; row++) {
            System.out.print("  ");
            for (int col = 0; col < n; col++) {
                System.out.print(queens[row] == col ? " Q " : " . ");
            }
            System.out.println();
        }
    }

    /**
     * Runs the solver and reports results.
     *
     * @param maxDisplay number of solutions to display visually (0 = all)
     */
    public void run(int maxDisplay) {
        solutionCount = 0;
        nodesExplored = 0;

        System.out.println("\n" + repeat("=", 55));
        System.out.printf("  N-Queens Solver  |  N = %d  |  Board: %dx%d%n", n, n, n);
        System.out.println(repeat("=", 55));

        if (maxDisplay > 0) {
            System.out.println("  Displaying first " + maxDisplay + " solution(s)...");
        } else {
            System.out.println("  Displaying ALL solutions...");
        }

        long startTime = System.nanoTime();
        solve(0, maxDisplay);
        long elapsed = System.nanoTime() - startTime;

        System.out.println("\n" + repeat("-", 55));
        System.out.printf("  Total distinct solutions : %d%n", solutionCount);
        System.out.printf("  Nodes explored           : %,d%n", nodesExplored);
        System.out.printf("  Time elapsed             : %.3f ms%n", elapsed / 1_000_000.0);
        System.out.println(repeat("=", 55));
    }

    /**
     * Returns the total number of solutions found in the last run.
     */
    public int getSolutionCount() {
        return solutionCount;
    }

    /**
     * Returns the number of nodes explored (backtracking tree nodes).
     */
    public long getNodesExplored() {
        return nodesExplored;
    }

    // Java 8 compatible repeat helper
    private static String repeat(String s, int times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) sb.append(s);
        return sb.toString();
    }
}
