# N-Queens Problem Solver
### DAA Group Project - Q5

Placing N queens on an N×N chessboard such that no two queens attack each other.  
Solved using **Backtracking with Pruning** in Java.

---

## Problem Statement

Given an N×N chessboard, place N queens so that no two queens share the same:
- Row
- Column
- Diagonal (both directions)

---

## Algorithm

**Approach:** Backtracking with a bounding function (pruning)

- Uses a 1D array where `queens[row] = column`
- Places queens row by row
- At each placement, the bounding function checks for conflicts
- If a conflict is found, that branch is pruned immediately (no further exploration)

**Bounding Function (`isSafe`):**
```
For each previously placed queen at (prevRow, prevCol):
  - Column conflict    : prevCol == col
  - Diagonal conflict  : |prevRow - row| == |prevCol - col|
```

**Complexity:**
| | Value |
|---|---|
| Time (worst case) | O(N!) |
| Space | O(N) — recursion depth |

Pruning reduces actual nodes explored drastically compared to brute force O(N^N).

---

## Results

| Board Size | Total Solutions | Nodes Explored | Time |
|---|---|---|---|
| N = 8  | 92      | 15,720      | ~16 ms  |
| N = 10 | 724     | 348,150     | ~25 ms  |
| N = 12 | 14,200  | 10,103,868  | ~260 ms |

---

## Project Structure

```
├── src/
│   ├── NQueens.java   # Core solver: backtracking, pruning, board display
│   └── Main.java      # Driver: runs N=8,10,12 and prints analysis
└── README.md
```

---

## How to Run

### In NetBeans
1. Open NetBeans → `File` → `New Project` → `Java Application`
2. Add `NQueens.java` and `Main.java` to the source package
3. Right-click `Main.java` → `Run File`

### In Terminal
```bash
javac src/NQueens.java src/Main.java -d out
java -cp out Main
```

---

## Sample Output

```
*******************************************************
*   DAA Group Project - Q5                           *
*   N-Queens Problem: Chess Board Arrangement        *
*   Algorithm: Backtracking with Pruning             *
*******************************************************

=======================================================
  N-Queens Solver  |  N = 8  |  Board: 8x8
=======================================================
  Solution #1:
  Column positions (by row): [ 1, 5, 8, 6, 3, 7, 2, 4 ]
  Board:
   Q  .  .  .  .  .  .  .
   .  .  .  .  Q  .  .  .
   .  .  .  .  .  .  .  Q
   .  .  .  .  .  Q  .  .
   .  .  Q  .  .  .  .  .
   .  .  .  .  .  .  Q  .
   .  Q  .  .  .  .  .  .
   .  .  .  Q  .  .  .  .

  Total distinct solutions : 92
  Nodes explored           : 15,720
  Time elapsed             : 16.103 ms
```

---

## Real-World Connections

1. **Constraint Satisfaction Problems (CSP)** — variables, domains, constraints
2. **Antenna Placement** — avoid signal interference along rows, columns, diagonals
3. **Task Scheduling** — assign tasks to slots with no resource conflicts
4. **VLSI Circuit Design** — place components avoiding electrical interference

---

## Requirements

- Java 8 or higher
- NetBeans IDE 8.2+ (or any Java IDE / terminal)
